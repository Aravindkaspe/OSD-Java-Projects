package ball.view;

public interface Observer {
    
}
