package minesweeper.Model;

import javax.swing.*;

public class Blocks extends JButton{
    int rows;
    int columns;
    public Blocks(int r, int c) {
        this.rows = r;
        this.columns = c;
    }
}
