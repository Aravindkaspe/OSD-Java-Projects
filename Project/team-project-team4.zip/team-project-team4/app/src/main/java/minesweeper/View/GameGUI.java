package minesweeper.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;
import minesweeper.Model.GamePanel;

public class GameGUI {
    JFrame frame;
    GamePanel panel;
    
    public void run() {
        JFrame gameFrame = new JFrame("Minesweeper");
        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
    
            
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel();
        titleLabel.setFont(new Font("Arial Unicode MS", Font.PLAIN, 30));
        titleLabel.setText("Minesweeper");
            
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); 
        titlePanel.add(titleLabel);
        titlePanel.setBorder(new EmptyBorder(20, 0, 20, 0));

        
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        JButton easyMode = new JButton("Easy");
        JButton normalMode = new JButton("Normal");
        JButton hardMode = new JButton("Hard");

        
        menuPanel.add(Box.createVerticalStrut(20)); 
        easyMode.setAlignmentX(Component.CENTER_ALIGNMENT); 
        menuPanel.add(easyMode);
        menuPanel.add(Box.createVerticalStrut(10)); 
        normalMode.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuPanel.add(normalMode);
        menuPanel.add(Box.createVerticalStrut(10)); 
        hardMode.setAlignmentX(Component.CENTER_ALIGNMENT);
        menuPanel.add(hardMode);

        JPanel containerPanel = new JPanel();
        containerPanel.setLayout(new BoxLayout(containerPanel, BoxLayout.Y_AXIS));
        containerPanel.add(titlePanel);
        containerPanel.add(menuPanel);
        containerPanel.setAlignmentX(Component.CENTER_ALIGNMENT); 

        
        gameFrame.getContentPane().add(containerPanel);

        gameFrame.setPreferredSize(new Dimension(600, 800));
        gameFrame.pack();
        gameFrame.setLocationRelativeTo(null);
        gameFrame.setVisible(true);
}

}
