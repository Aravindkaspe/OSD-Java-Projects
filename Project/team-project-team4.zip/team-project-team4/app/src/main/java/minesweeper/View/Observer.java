package minesweeper.View;

public interface Observer {
    public void update(String result);
}
