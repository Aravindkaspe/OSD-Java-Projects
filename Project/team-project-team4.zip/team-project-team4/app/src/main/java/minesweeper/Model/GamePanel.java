package minesweeper.Model;

import minesweeper.View.Observer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GamePanel extends JPanel implements Observer{
    JPanel infoPanel;
    JLabel timeLabel;
    JButton button;
    ArrayList<JButton> buttonsArray;
    int rows = 5;
    int cols = 5;
    int WIDTH = 500;
    int HEIGHT = 500;
    protected JPanel gamePanel;
    protected JPanel modeLabelPanel;
    protected JLabel modeLabel;
    protected JPanel containerPanel;
    protected JPanel labelsPanel;
    protected JPanel highScoreLabelPanel;
    protected JLabel highScoreLabel;

    public GamePanel() {
        setLayout(new BorderLayout());
        infoPanel = new JPanel();
        infoPanel.setLayout(new BorderLayout());
        infoPanel.setBorder(new EmptyBorder(0, 0, 10, 20)); 

        timeLabel = new JLabel("Time: 0");
        timeLabel.setHorizontalAlignment(SwingConstants.RIGHT); 
        infoPanel.add(timeLabel, BorderLayout.NORTH);

        add(infoPanel, BorderLayout.NORTH);

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(rows, cols, 2, 2));

        buttonsArray = new ArrayList<>();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                button = new JButton();
                buttonsPanel.add(button);
                buttonsArray.add(button);
            }
        }

        add(buttonsPanel, BorderLayout.CENTER);

        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }

    public JPanel createPanel(String mode, Game game) {
        modeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        modeLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        modeLabel.setText("Mines: " + game.getMines());
        modeLabel.setBorder(new EmptyBorder(10, 0, 20, 0));
        modeLabelPanel.add(modeLabel); // Add modeLabel to modeLabelPanel
        highScoreLabel.setBorder(new EmptyBorder(10, 0, 20, 0));
        highScoreLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        highScoreLabelPanel.add(highScoreLabel);
        
        labelsPanel.add(modeLabelPanel, BorderLayout.CENTER); // Add modeLabelPanel to the left
        labelsPanel.add(highScoreLabelPanel, BorderLayout.EAST); // Add highScoreLabelPanel to the right
        containerPanel.add(labelsPanel, BorderLayout.NORTH); // Add labelsPanel to the top

        if (mode.equals("easy")) {
            gamePanel = new JPanel(new GridLayout(5, 5, 2, 2)); // Change layout to GridLayout
        } else if (mode.equals("normal")) {
            gamePanel = new JPanel(new GridLayout(7, 7, 2, 2)); // Change layout to GridLayout
        } else {
            gamePanel = new JPanel(new GridLayout(11, 11, 2, 2)); // Change layout to GridLayout
            gamePanel.setFont(new Font("Arial Unicode MS", Font.PLAIN, 40));
        }

        for (int i = 0; i < game.getRowSize(); i++) {
            for (int j = 0; j < game.getColumnSize(); j++) {
                Blocks block = new Blocks(i, j);
                gamePanel.add(block); 
            }
        }

        containerPanel.add(gamePanel, BorderLayout.CENTER); 
        return containerPanel;
    }

    public void update(String result) {
        modeLabel.setText(result);
    }

}